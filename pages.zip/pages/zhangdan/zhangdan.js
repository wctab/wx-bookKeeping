// pages/zhangdan/zhangdan.js
var app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    baseImg:"",
    book:"默认账本",
    title:"默认账本",
    title2:"",
    xianH:"",
    tou_xia:"img/sanjiaojiantou_xia.png",
    tou_shang:"img/sanjiaojiantou_shang.png",
    list: ["旅游账本", "生意账本"],
    dheader:"dheader",
    timer:"",
    timer2:""
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var title = this.data.title;

    var query = wx.createSelectorQuery();
    query.select('#scrollH').boundingClientRect()
    query.exec((res) => {
        var height = res[0].height+"px";
        console.log("线稿 ",height)
        this.setData({
          xianH:height
        })
    })


    this.setData({title2:title})
    if (app.globalData.imgUrl){
        this.setData({
          baseImg: app.globalData.imgUrl
        })
    }
  },
  touchs(){
    this.data.timer = setInterval(()=>{
      var query = wx.createSelectorQuery();
      query.select('#container').boundingClientRect()
      query.exec((res) => {
        var top = res[0].top; // 获取高度
        console.log(top)
        var dheader = this.data.dheader;
        if (!dheader){
          query.select('#dheader').boundingClientRect()
          query.exec((res) => {
            var height = res[0].height;
            console.log("true",height);
            if (top > 65 && top < 50 + 65) {

              this.setData({
                title: "下拉同步",
              })

            } else if (top > 50 + 65) {
              this.setData({
                title: "释放同步"
              })
            }
          })
        }else{
          query.select('#dheader').boundingClientRect()
          query.exec((res) => {
            var height = res[0].height;
            console.log("true", height);
            console.log("false", height);
            if (top > 0 && top < 50) {

              this.setData({
                title: "下拉同步",
              })

            } else if (top > 50) {
              this.setData({
                title: "释放同步"
              })
            }
          })
        }
      })
    })

  },
  leave(){
    var timer = this.data.timer
    clearInterval(timer)
    this.data.timer2=setInterval(()=>{
      var query = wx.createSelectorQuery();
      query.select('#container').boundingClientRect()
      query.exec((res) => {
        var top = res[0].top;
       // console.log(top)
        var dheader = this.data.dheader;
        if (!dheader) {
          query.select('#dheader').boundingClientRect()
          query.exec((res) => {
            if (top == 125) {
              var title = this.data.title2
              this.setData({
                title: title
              })
              var timer2 = this.data.timer2
              clearInterval(timer2)
            }
          })
        }else{
        if(top==0){
          var title = this.data.title2
          this.setData({
            title: title
          })
          var timer2 = this.data.timer2
          clearInterval(timer2)
        }
        }
      })
     
    })
  },
  dheader(){
    var dh = this.data.dheader;
    var xia = this.data.tou_xia;
    var shang = this.data.tou_shang;
    console.log(123)
    if(dh){
      this.setData({
        dheader: "",
        tou_xia: shang,
        tou_shang: xia
      })

    }else{
      this.setData({
        dheader: "dheader",
        tou_xia: shang,
        tou_shang: xia
      })
    }
  },
 




  onTabItemTap(item) {
    var url ="pages/zhangdan/zhangdan"
    if (item.pagePath==url){
      wx.redirectTo({
        url: '/pages/addzhangdan/addzhangdan',
      })
    }

  },
  // bindViewTap(){
  //   wx.switchTab({ 非tabBar转tabBar页面使用
  //     url: '/pages/addzhangdan/addzhangdan',
  //   })
  // },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    setTimeout(()=>{
      wx.stopPullDownRefresh()
    },150)
  },
  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    wx.stopPullDownRefresh()
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
  
})