// pages/qianbao/qianbao.js
var app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    baseImg: "",
    richactive:"active",
    pooractive: "",
    property:"",
    poorproperty:"property"
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    if (app.globalData.imgUrl) {
      this.setData({
        baseImg: app.globalData.imgUrl
      })
    }

  
  },
  add(){
    wx.navigateTo({
      url:"/pages/account/account"
    })
  },
  richtop(){
    var richactive = this.data.richactive;
    if (!richactive){
      this.setData({
        richactive: "active",
        pooractive: "",
        property: "",
        poorproperty: "property"
      })
    }
  },
  poortop(){
    var pooractive = this.data.pooractive;
    if(!pooractive){
      this.setData({
        richactive: "",
        pooractive: "active",
        property: "property",
        poorproperty: ""
      })
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})