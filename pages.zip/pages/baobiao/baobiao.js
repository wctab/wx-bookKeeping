// pages/baobiao/baobiao.js
const app=getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    baseImg:"",
    userInfo:{},
    windowHeight:"",
    hasUserInfo:false,
    canIUse:wx.canIUse('button.pen-type.getUserInfo'),
    navData:["分类","趋势","对比","成员"],
    currentTab:0
  
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

    if (app.globalData.imgUrl){
      this.setData({
        baseImg: app.globalData.imgUrl
      })
    }
      if(app.globalData.userInfo){
        this.setData({
          userInfo: app.globalData.userInfo,
          hasUserInfo: true
        })
      }else if(this.data.canIUse){
        // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
        // 所以此处加入 callback 以防止这种情况
        app.userInfoReadyCallback = res => {
          this.setData({
            userInfo: res.userInfo,
            hasUserInfo: true
          })
        }
      }else{
        // 在没有 open-type=getUserInfo 版本的兼容处理
        wx.getUserInfo({
          success: res => {
            app.globalData.userInfo = res.userInfo
            this.setData({
              userInfo: res.userInfo,
              hasUserInfo: true
            })
          }
        })
      }
      wx.getSystemInfo({
        success: (res)=>{
          this.setData({
            pixelRatio: res.pixelRatio,
            windowHeight: res.windowHeight,
            windowWidth: res.windowWidth
          })
        },
      })
      console.log("height", this.data.windowHeight);

  
  },
  switchNav(event){
    var idx = event.currentTarget.dataset.current;
    this.setData({
      currentTab: idx
    })
  },
  switchTab(event){
    var idx = event.detail.current;
    this.setData({
      currentTab:idx
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})